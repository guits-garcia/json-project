<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Página do Usuário</title>
</head>
<body>

    <?php if($_GET['autor-id']){
        $proxy = '192.168.10.254:3128';
        $autor_id = $_GET['autor-id'];
        echo $autor_id;
        $cr = curl_init(); 
        curl_setopt($cr, CURLOPT_URL, "https://jsonplaceholder.typicode.com/users?id=$autor_id");
        curl_setopt($cr, CURLOPT_PROXY, $proxy);
        curl_setopt($cr, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($cr);
        $usuario = json_decode($data);
        //fazer um layout com os dados no json users, que dependendo do valor do get já vai puxar de cada um.
        //integrar o here maps!!!!
    }
    ?>    



</body>
</html>