<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>JSON request</title>
</head>
<body>
    <?php 
    
    $cr = curl_init();
    $proxy = '192.168.10.254:3128';
    //definindo a url de busca 
    curl_setopt($cr, CURLOPT_URL, "https://jsonplaceholder.typicode.com/posts"); //pega os POSTS
    //Set CURLOPT_RETURNTRANSFER so that the content is returned as a variable.
    curl_setopt($cr, CURLOPT_PROXY, $proxy);
    curl_setopt($cr, CURLOPT_RETURNTRANSFER, true);
    //Execute the request.
    $data = curl_exec($cr);
    $posts = json_decode($data); //transforma o json em um array php
    //Close the cURL handle.
    curl_close($cr);
    
    // $cr = curl_init(); 
    // curl_setopt($cr, CURLOPT_URL, "https://jsonplaceholder.typicode.com/comments"); //pega os POSTS, estou chamando lá em baixo
    // curl_setopt($cr, CURLOPT_RETURNTRANSFER, true);
    // $data = curl_exec($cr);
    // $comentarios = json_decode($data);
    // echo "<pre>";
    // print_r($comentarios);
    // curl_close($cr);


    ?>
    <section id="posts">
        <?php foreach ($posts as $post){
            echo "<div class='post'>
                        <p class='title'> $post->title </p>
                        <div class='post-info'>
                            <p>Post de número: $post->id </p>
                            <form action='autor-page.php'>
                                <button type='submit' name='autor-id' id='autor-id' value='$post->userId'>
                                    Id do autor: $post->userId
                                </button></p>
                            </form>
                        </div>
                        <p class='content'> $post->body </p>
                        <div class='comentarios'>
                        <p> Veja o que as pessoas estão falando sobre o assunto: </p>";
                            //aqui gero o código pra puxar apenas o comm referentes ao post atual do foreach $posts
                            $cr = curl_init(); 
                            $proxy = '192.168.10.254:3128';
                            curl_setopt($cr, CURLOPT_URL, "https://jsonplaceholder.typicode.com/comments?postId=$post->id");
                            curl_setopt($cr, CURLOPT_PROXY, $proxy);
                            curl_setopt($cr, CURLOPT_RETURNTRANSFER, true);
                            $data = curl_exec($cr);
                            $comentarios = json_decode($data);
                            curl_close($cr);
                            foreach ($comentarios as $comentario){
                                echo "<div class='comentario'>
                                        
                                        <div class='comentario-info'>
                                            <p>Comentário <b>#$comentario->id</b>  &nbsp </p>
                                            <p> por $comentario->email: </p>
                                        </div>
                                        <div class='comentario-conteudo'>
                                            <p> $comentario->body </p>
                                        </div>
                                      </div>";
                            }
                    echo "</div>
                  </div>";
        } ?>
    </section>
</body>
</html>