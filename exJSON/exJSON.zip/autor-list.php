<?php include 'header.php'; ?>


<section id="autor-list">
    <h1>CONHEÇA NOSSOS CRIADORES</h1>
    <div class="profile-pics">
        <?php

        $ch = curl_init(); 
        $proxy = '192.168.10.254:3128';
        curl_setopt($ch, CURLOPT_URL, 'https://jsonplaceholder.typicode.com/users/'); // request dos POSTS
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $json =  curl_exec($ch);
        $users = json_decode($json);
        curl_close($ch);
        foreach ($users as $user){
            //para cada user, pegar o user->id e jogar como parametro no json que eu vou criar com as fotos
            echo "<div class='profile-pic'>";
                // <img src=''> aqui vai a url que vai ter no json
            echo "<p>$user->username</p>
            <div class='phone-web-mail'>
            <img src='phone.png'>
            <i class='fas fa-mobile-alt'></i>

            </div>
            </div>";
        }

?>
    </div>
</section>






<?php @include 'footer.php'; ?>